import javax.swing.*;
import java.awt.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class WaterConsumptionChart extends JPanel {
    private List<Double> readings;
    private List<LocalDateTime> timestamps;
    private double maxReading = 100.0; // Initial scale

    public WaterConsumptionChart() {
        readings = new ArrayList<>();
        timestamps = new ArrayList<>();
        setPreferredSize(new Dimension(600, 300));
        setBorder(BorderFactory.createTitledBorder("Water Consumption Over Time"));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int padding = 40;
        int width = getWidth() - 2 * padding;
        int height = getHeight() - 2 * padding;
        int baseY = getHeight() - padding;

        // Draw axes
        g2.drawLine(padding, padding, padding, baseY); // Y axis
        g2.drawLine(padding, baseY, getWidth() - padding, baseY); // X axis

        // Draw readings
        if (readings.size() > 1) {
            int numPoints = readings.size();
            int pointSpacing = width / (numPoints - 1);

            // Update max reading if needed
            maxReading = Math.max(maxReading, readings.stream().mapToDouble(d -> d).max().orElse(100.0));

            // Draw Y-axis labels
            g2.drawString(String.format("%.1f m³", maxReading), 5, padding);
            g2.drawString("0 m³", 5, baseY);

            // Draw points and connect them
            for (int i = 0; i < numPoints; i++) {
                int x = padding + (i * pointSpacing);
                int y = baseY - (int)((readings.get(i) / maxReading) * height);

                // Draw point
                g2.fillOval(x - 3, y - 3, 6, 6);

                // Connect to previous point
                if (i > 0) {
                    int prevX = padding + ((i - 1) * pointSpacing);
                    int prevY = baseY - (int)((readings.get(i - 1) / maxReading) * height);
                    g2.drawLine(prevX, prevY, x, y);
                }

                // Draw timestamp label (only for first and last points)
                if (i == 0 || i == numPoints - 1) {
                    String timeLabel = timestamps.get(i).getHour() + ":" + 
                                     String.format("%02d", timestamps.get(i).getMinute());
                    g2.drawString(timeLabel, x - 15, baseY + 15);
                }
            }
        }
    }

    public void addReading(LocalDateTime dateTime, double value) {
        readings.add(value);
        timestamps.add(dateTime);
        // Keep only last 10 readings for simplicity
        if (readings.size() > 10) {
            readings.remove(0);
            timestamps.remove(0);
        }
        repaint();
    }
} 