import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class DatabaseConnection {
    private Connection connection;

    public DatabaseConnection() {
        try {
            // Register JDBC driver for SQLite
            Class.forName("org.sqlite.JDBC");
            
            // Open/create a database file in the project directory
            connection = DriverManager.getConnection("jdbc:sqlite:water_monitoring.db");
            
            // Create tables if they don't exist
            createTables();
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, 
                "Database connection failed: " + e.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void createTables() throws SQLException {
        String createBuildingsTable = 
            "CREATE TABLE IF NOT EXISTS buildings (" +
            "    id INTEGER PRIMARY KEY," +
            "    name TEXT," +
            "    address TEXT" +
            ")";

        String createReadingsTable = 
            "CREATE TABLE IF NOT EXISTS water_readings (" +
            "    id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "    building_id INTEGER," +
            "    reading_value REAL," +
            "    timestamp TEXT," +
            "    FOREIGN KEY (building_id) REFERENCES buildings(id)" +
            ")";

        try (Statement stmt = connection.createStatement()) {
            stmt.execute(createBuildingsTable);
            stmt.execute(createReadingsTable);
        }

        // Create default building if none exists
        try (Statement stmt = connection.createStatement()) {
            ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM buildings");
            if (rs.next() && rs.getInt(1) == 0) {
                addBuilding("Main Building", "123 Main Street");
            }
        }
    }

    public void addReading(int buildingId, double reading, LocalDateTime timestamp) throws SQLException {
        // First, ensure the building exists
        ensureBuildingExists(buildingId);
        
        String sql = "INSERT INTO water_readings (building_id, reading_value, timestamp) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, buildingId);
            pstmt.setDouble(2, reading);
            pstmt.setString(3, timestamp.toString()); // SQLite doesn't have a DATETIME type
            pstmt.executeUpdate();
        }
    }

    private void ensureBuildingExists(int buildingId) throws SQLException {
        String checkSql = "SELECT id FROM buildings WHERE id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(checkSql)) {
            pstmt.setInt(1, buildingId);
            ResultSet rs = pstmt.executeQuery();
            
            if (!rs.next()) {
                String insertSql = "INSERT INTO buildings (id, name) VALUES (?, ?)";
                try (PreparedStatement insertStmt = connection.prepareStatement(insertSql)) {
                    insertStmt.setInt(1, buildingId);
                    insertStmt.setString(2, "Building " + buildingId);
                    insertStmt.executeUpdate();
                }
            }
        }
    }

    public List<WaterReading> getReadings(int buildingId) throws SQLException {
        List<WaterReading> readings = new ArrayList<>();
        String sql = "SELECT * FROM water_readings WHERE building_id = ? ORDER BY timestamp DESC LIMIT 100";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, buildingId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                readings.add(new WaterReading(
                    rs.getInt("building_id"),
                    rs.getDouble("reading_value"),
                    LocalDateTime.parse(rs.getString("timestamp"))
                ));
            }
        }
        return readings;
    }

    public void close() {
        try {
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Connection getConnection() {
        return connection;
    }

    public List<Building> getAllBuildings() throws SQLException {
        List<Building> buildings = new ArrayList<>();
        String sql = "SELECT * FROM buildings ORDER BY name";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                buildings.add(new Building(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("address")
                ));
            }
        }
        return buildings;
    }

    public Building getBuildingByName(String name) throws SQLException {
        String sql = "SELECT * FROM buildings WHERE name = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, name);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new Building(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("address")
                );
            }
        }
        return null;
    }

    public void addBuilding(String name, String address) throws SQLException {
        String sql = "INSERT INTO buildings (name, address) VALUES (?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setString(2, address);
            pstmt.executeUpdate();
        }
    }

    public void deleteBuilding(int buildingId) throws SQLException {
        // First delete associated records
        String deleteReadings = "DELETE FROM water_readings WHERE building_id = ?";
        String deleteUserBuildings = "DELETE FROM user_buildings WHERE building_id = ?";
        String deleteBuilding = "DELETE FROM buildings WHERE id = ?";

        try (PreparedStatement pstmt1 = connection.prepareStatement(deleteReadings);
             PreparedStatement pstmt2 = connection.prepareStatement(deleteUserBuildings);
             PreparedStatement pstmt3 = connection.prepareStatement(deleteBuilding)) {
            
            connection.setAutoCommit(false);
            try {
                pstmt1.setInt(1, buildingId);
                pstmt1.executeUpdate();

                pstmt2.setInt(1, buildingId);
                pstmt2.executeUpdate();

                pstmt3.setInt(1, buildingId);
                pstmt3.executeUpdate();

                connection.commit();
            } catch (SQLException e) {
                connection.rollback();
                throw e;
            } finally {
                connection.setAutoCommit(true);
            }
        }
    }

    public void createAlertTable() throws SQLException {
        String createAlertsTable = 
            "CREATE TABLE IF NOT EXISTS alerts (" +
            "    id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "    building_id INTEGER," +
            "    message TEXT," +
            "    timestamp TEXT," +
            "    severity TEXT," +
            "    FOREIGN KEY (building_id) REFERENCES buildings(id)" +
            ")";

        try (Statement stmt = connection.createStatement()) {
            stmt.execute(createAlertsTable);
        }
    }

    public void saveAlert(Alert alert) throws SQLException {
        String sql = "INSERT INTO alerts (building_id, message, timestamp, severity) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, alert.getBuilding().getId());
            pstmt.setString(2, alert.getMessage());
            pstmt.setString(3, alert.getTimestamp().toString());
            pstmt.setString(4, alert.getSeverity().name());
            pstmt.executeUpdate();
        }
    }

    public List<Alert> loadAlerts() throws SQLException {
        List<Alert> alerts = new ArrayList<>();
        String sql = "SELECT a.*, b.name, b.address FROM alerts a " +
                     "JOIN buildings b ON a.building_id = b.id " +
                     "ORDER BY timestamp DESC";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Building building = new Building(
                    rs.getInt("building_id"),
                    rs.getString("name"),
                    rs.getString("address")
                );
                
                Alert alert = new Alert(
                    building,
                    rs.getString("message"),
                    LocalDateTime.parse(rs.getString("timestamp")),
                    AlertSeverity.valueOf(rs.getString("severity"))
                );
                alerts.add(alert);
            }
        }
        return alerts;
    }
} 