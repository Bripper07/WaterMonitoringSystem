import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.sql.SQLException;

public class SignupDialog extends JDialog {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JPasswordField confirmPasswordField;
    private JComboBox<UserRole> roleComboBox;
    private JList<Building> buildingList;
    private boolean succeeded;
    private UserAuth userAuth;
    private JLabel passwordStrengthLabel;
    private JTextArea requirementsArea;

    public SignupDialog(Frame parent, UserAuth userAuth) {
        super(parent, "Sign Up", true);
        this.userAuth = userAuth;
        
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints cs = new GridBagConstraints();
        cs.fill = GridBagConstraints.HORIZONTAL;
        cs.insets = new Insets(5, 5, 5, 5);

        // Username
        cs.gridx = 0;
        cs.gridy = 0;
        panel.add(new JLabel("Username: "), cs);

        cs.gridx = 1;
        usernameField = new JTextField(20);
        panel.add(usernameField, cs);

        // Password
        cs.gridx = 0;
        cs.gridy = 1;
        panel.add(new JLabel("Password: "), cs);

        cs.gridx = 1;
        passwordField = new JPasswordField(20);
        panel.add(passwordField, cs);

        // Confirm Password
        cs.gridx = 0;
        cs.gridy = 2;
        panel.add(new JLabel("Confirm Password: "), cs);

        cs.gridx = 1;
        confirmPasswordField = new JPasswordField(20);
        panel.add(confirmPasswordField, cs);

        // Role Selection
        cs.gridx = 0;
        cs.gridy = 3;
        panel.add(new JLabel("Role: "), cs);

        cs.gridx = 1;
        roleComboBox = new JComboBox<>(UserRole.values());
        panel.add(roleComboBox, cs);

        // Building Selection
        cs.gridx = 0;
        cs.gridy = 4;
        panel.add(new JLabel("Buildings: "), cs);

        cs.gridx = 1;
        DefaultListModel<Building> buildingModel = new DefaultListModel<>();
        try {
            for (Building building : userAuth.getDatabase().getAllBuildings()) {
                buildingModel.addElement(building);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        buildingList = new JList<>(buildingModel);
        buildingList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        JScrollPane buildingScroll = new JScrollPane(buildingList);
        buildingScroll.setPreferredSize(new Dimension(200, 100));
        panel.add(buildingScroll, cs);

        // Add password requirements area
        cs.gridx = 1;
        cs.gridy = 5;
        requirementsArea = new JTextArea(PasswordValidator.getRequirements());
        requirementsArea.setEditable(false);
        requirementsArea.setBackground(panel.getBackground());
        requirementsArea.setFont(new Font(Font.SANS_SERIF, Font.ITALIC, 10));
        requirementsArea.setLineWrap(true);
        requirementsArea.setWrapStyleWord(true);
        panel.add(requirementsArea, cs);

        // Add password strength indicator
        cs.gridx = 1;
        cs.gridy = 6;
        passwordStrengthLabel = new JLabel(" ");
        panel.add(passwordStrengthLabel, cs);

        // Add real-time password validation
        passwordField.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void changedUpdate(javax.swing.event.DocumentEvent e) { updatePasswordStrength(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { updatePasswordStrength(); }
            public void insertUpdate(javax.swing.event.DocumentEvent e) { updatePasswordStrength(); }
        });

        // Add username availability checker
        usernameField.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void changedUpdate(javax.swing.event.DocumentEvent e) { checkUsername(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { checkUsername(); }
            public void insertUpdate(javax.swing.event.DocumentEvent e) { checkUsername(); }
        });

        // Buttons
        JPanel bp = new JPanel();
        JButton btnSignup = new JButton("Sign Up");
        JButton btnCancel = new JButton("Cancel");

        bp.add(btnSignup);
        bp.add(btnCancel);

        btnSignup.addActionListener(e -> signup());
        btnCancel.addActionListener(e -> dispose());

        getContentPane().add(panel, BorderLayout.CENTER);
        getContentPane().add(bp, BorderLayout.PAGE_END);

        pack();
        setResizable(false);
        setLocationRelativeTo(parent);
    }

    private void signup() {
        try {
            String username = usernameField.getText().trim();
            String password = new String(passwordField.getPassword());
            String confirmPassword = new String(confirmPasswordField.getPassword());
            UserRole role = (UserRole) roleComboBox.getSelectedItem();
            
            // Get selected buildings
            List<Building> selectedBuildings = buildingList.getSelectedValuesList();
            int[] buildingIds = selectedBuildings.stream()
                .mapToInt(Building::getId)
                .toArray();

            // Validation
            if (username.isEmpty() || password.isEmpty()) {
                throw new IllegalArgumentException("Username and password are required");
            }

            if (!password.equals(confirmPassword)) {
                throw new IllegalArgumentException("Passwords do not match");
            }

            if (userAuth.isUsernameTaken(username)) {
                throw new IllegalArgumentException("Username is already taken");
            }

            if (!PasswordValidator.isStrong(password)) {
                throw new IllegalArgumentException("Password does not meet requirements:\n" + 
                    PasswordValidator.getRequirements());
            }

            userAuth.createUser(username, password, role, buildingIds);
            succeeded = true;
            JOptionPane.showMessageDialog(this,
                "Account created successfully!",
                "Success",
                JOptionPane.INFORMATION_MESSAGE);
            dispose();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Failed to create account: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updatePasswordStrength() {
        String password = new String(passwordField.getPassword());
        if (password.isEmpty()) {
            passwordStrengthLabel.setText(" ");
            return;
        }

        if (PasswordValidator.isStrong(password)) {
            passwordStrengthLabel.setText("Strong password");
            passwordStrengthLabel.setForeground(new Color(0, 150, 0));
        } else {
            passwordStrengthLabel.setText("Weak password");
            passwordStrengthLabel.setForeground(Color.RED);
        }
    }

    private void checkUsername() {
        String username = usernameField.getText().trim();
        if (username.isEmpty()) {
            return;
        }

        if (userAuth.isUsernameTaken(username)) {
            usernameField.setBackground(new Color(255, 200, 200));
            usernameField.setToolTipText("Username already taken");
        } else {
            usernameField.setBackground(Color.WHITE);
            usernameField.setToolTipText(null);
        }
    }

    public boolean isSucceeded() {
        return succeeded;
    }
} 