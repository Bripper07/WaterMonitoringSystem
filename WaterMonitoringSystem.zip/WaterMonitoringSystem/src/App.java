// Main application class
public class App {
    public static void main(String[] args) {
        System.out.println("Water Monitoring System Starting...");
        
        // Initialize the water meter
        WaterMeter waterMeter = new WaterMeter();
        
        // Add shutdown hook to close database connection
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            System.out.println("Shutting down...");
            waterMeter.close();
        }));
        
        // Create and display the GUI
        javax.swing.SwingUtilities.invokeLater(() -> {
            WaterMonitoringGUI gui = new WaterMonitoringGUI(waterMeter);
            gui.display();
        });
    }
}
