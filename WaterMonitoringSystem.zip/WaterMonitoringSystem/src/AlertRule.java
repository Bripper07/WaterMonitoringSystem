import java.util.List;

public interface AlertRule {
    boolean evaluate(List<WaterReading> readings);
    String getDescription();
} 