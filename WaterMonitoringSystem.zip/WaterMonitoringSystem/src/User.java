public class User {
    private int id;
    private String username;
    private String passwordHash;
    private UserRole role;
    private int[] assignedBuildings; // Buildings this user can access

    public User(int id, String username, String passwordHash, UserRole role, int[] assignedBuildings) {
        this.id = id;
        this.username = username;
        this.passwordHash = passwordHash;
        this.role = role;
        this.assignedBuildings = assignedBuildings;
    }

    public int getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public UserRole getRole() {
        return role;
    }

    public int[] getAssignedBuildings() {
        return assignedBuildings;
    }

    public boolean canAccessBuilding(int buildingId) {
        if (role == UserRole.ADMIN) return true;
        for (int b : assignedBuildings) {
            if (b == buildingId) return true;
        }
        return false;
    }
} 