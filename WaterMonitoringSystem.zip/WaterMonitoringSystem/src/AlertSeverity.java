public enum AlertSeverity {
    LOW,
    MEDIUM,
    HIGH
} 