import java.util.List;

public class ConsumptionSpikeRule implements AlertRule {
    private double threshold;

    public ConsumptionSpikeRule(double threshold) {
        this.threshold = threshold;
    }

    @Override
    public boolean evaluate(List<WaterReading> readings) {
        if (readings.size() < 2) return false;
        
        double latest = readings.get(0).getValue();
        double average = readings.stream()
            .mapToDouble(WaterReading::getValue)
            .average()
            .orElse(0.0);

        return latest > average * (1 + threshold/100);
    }

    @Override
    public String getDescription() {
        return String.format("Consumption spike detected (>%.1f%% above average)", threshold);
    }
} 