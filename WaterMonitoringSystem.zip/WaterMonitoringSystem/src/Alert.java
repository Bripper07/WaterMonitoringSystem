import java.time.LocalDateTime;

public class Alert {
    private Building building;
    private String message;
    private LocalDateTime timestamp;
    private AlertSeverity severity;

    public Alert(Building building, String message, LocalDateTime timestamp, AlertSeverity severity) {
        this.building = building;
        this.message = message;
        this.timestamp = timestamp;
        this.severity = severity;
    }

    public Building getBuilding() { return building; }
    public String getMessage() { return message; }
    public LocalDateTime getTimestamp() { return timestamp; }
    public AlertSeverity getSeverity() { return severity; }

    @Override
    public String toString() {
        return String.format("[%s] %s - %s: %s",
            timestamp.toString(),
            severity,
            building.getName(),
            message);
    }
} 