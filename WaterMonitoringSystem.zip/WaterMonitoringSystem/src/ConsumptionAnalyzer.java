import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.OptionalDouble;

public class ConsumptionAnalyzer {
    private DatabaseConnection db;
    private static final double ANOMALY_THRESHOLD = 0.30; // 30% above average is considered anomalous

    public ConsumptionAnalyzer(DatabaseConnection db) {
        this.db = db;
    }

    public AnalysisResult analyzeConsumption(int buildingId) {
        try {
            List<WaterReading> readings = db.getReadings(buildingId);
            if (readings.size() < 2) {
                return new AnalysisResult(0, 0, 0, false, "Insufficient data for analysis");
            }

            // Calculate daily consumption
            double latestReading = readings.get(0).getValue();
            double previousReading = readings.get(1).getValue();
            double dailyConsumption = latestReading - previousReading;

            // Calculate average consumption
            double avgConsumption = calculateAverageConsumption(readings);

            // Calculate weekly average
            double weeklyAvg = calculateWeeklyAverage(readings);

            // Check for anomalies
            boolean isAnomalous = isConsumptionAnomalous(dailyConsumption, avgConsumption);

            String message = createAnalysisMessage(dailyConsumption, avgConsumption, weeklyAvg, isAnomalous);

            return new AnalysisResult(
                dailyConsumption,
                avgConsumption,
                weeklyAvg,
                isAnomalous,
                message
            );
        } catch (Exception e) {
            e.printStackTrace();
            return new AnalysisResult(0, 0, 0, false, "Error analyzing consumption: " + e.getMessage());
        }
    }

    private double calculateAverageConsumption(List<WaterReading> readings) {
        if (readings.size() < 2) return 0;

        double sum = 0;
        int count = 0;
        
        for (int i = 0; i < readings.size() - 1; i++) {
            double consumption = readings.get(i).getValue() - readings.get(i + 1).getValue();
            if (consumption > 0) {  // Only count positive consumption
                sum += consumption;
                count++;
            }
        }

        return count > 0 ? sum / count : 0;
    }

    private double calculateWeeklyAverage(List<WaterReading> readings) {
        if (readings.isEmpty()) return 0;

        LocalDateTime weekAgo = LocalDateTime.now().minus(7, ChronoUnit.DAYS);
        
        OptionalDouble weeklyAvg = readings.stream()
            .filter(r -> r.getTimestamp().isAfter(weekAgo))
            .mapToDouble(WaterReading::getValue)
            .average();

        return weeklyAvg.orElse(0.0);
    }

    private boolean isConsumptionAnomalous(double current, double average) {
        if (average == 0) return false;
        return current > average * (1 + ANOMALY_THRESHOLD);
    }

    private String createAnalysisMessage(double daily, double average, double weekly, boolean anomalous) {
        StringBuilder message = new StringBuilder();
        message.append(String.format("Daily consumption: %.2f m³\n", daily));
        message.append(String.format("Average consumption: %.2f m³\n", average));
        message.append(String.format("Weekly average: %.2f m³\n", weekly));
        
        if (anomalous) {
            message.append("\nWARNING: Unusual water consumption detected!\n");
            double percentageIncrease = ((daily - average) / average) * 100;
            message.append(String.format("Current consumption is %.1f%% above average.\n", percentageIncrease));
            message.append("Please check for possible leaks or unusual usage patterns.");
        }

        return message.toString();
    }
} 