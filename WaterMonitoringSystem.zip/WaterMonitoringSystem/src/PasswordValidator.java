public class PasswordValidator {
    private static final int MIN_LENGTH = 8;
    private static final String SPECIAL_CHARS = "!@#$%^&*()_+-=[]{}|;:,.<>?";

    public static boolean isStrong(String password) {
        if (password.length() < MIN_LENGTH) {
            return false;
        }

        boolean hasUpperCase = false;
        boolean hasLowerCase = false;
        boolean hasDigit = false;
        boolean hasSpecialChar = false;

        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasUpperCase = true;
            else if (Character.isLowerCase(c)) hasLowerCase = true;
            else if (Character.isDigit(c)) hasDigit = true;
            else if (SPECIAL_CHARS.indexOf(c) >= 0) hasSpecialChar = true;
        }

        return hasUpperCase && hasLowerCase && hasDigit && hasSpecialChar;
    }

    public static String getRequirements() {
        return String.format(
            "Password must:\n" +
            "- Be at least %d characters long\n" +
            "- Contain at least one uppercase letter\n" +
            "- Contain at least one lowercase letter\n" +
            "- Contain at least one number\n" +
            "- Contain at least one special character (%s)",
            MIN_LENGTH, SPECIAL_CHARS
        );
    }
} 