import javax.swing.*;
import java.awt.*;
import javax.swing.table.DefaultTableModel;
import java.time.format.DateTimeFormatter;
import java.sql.SQLException;
import java.util.List;

public class AlertDialog extends JDialog implements AlertListener {
    private DefaultTableModel tableModel;
    private JTable alertTable;
    private static final DateTimeFormatter DATE_FORMAT = 
        DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private DatabaseConnection db;

    public AlertDialog(Frame parent, DatabaseConnection db) {
        super(parent, "Alerts", false);
        this.db = db;
        setupUI();
        loadSavedAlerts();
    }

    private void setupUI() {
        setLayout(new BorderLayout());

        // Create table
        String[] columns = {"Time", "Building", "Severity", "Message"};
        tableModel = new DefaultTableModel(columns, 0);
        alertTable = new JTable(tableModel);
        
        // Custom renderer for severity
        alertTable.getColumn("Severity").setCellRenderer((table, value, isSelected, hasFocus, row, column) -> {
            JLabel label = new JLabel(value.toString());
            if (value == AlertSeverity.HIGH) {
                label.setForeground(Color.RED);
            } else if (value == AlertSeverity.MEDIUM) {
                label.setForeground(Color.ORANGE);
            }
            return label;
        });

        JScrollPane scrollPane = new JScrollPane(alertTable);
        add(scrollPane, BorderLayout.CENTER);

        // Clear button
        JButton clearButton = new JButton("Clear Alerts");
        clearButton.addActionListener(e -> tableModel.setRowCount(0));
        add(clearButton, BorderLayout.SOUTH);

        setSize(600, 300);
        setLocationRelativeTo(getParent());
    }

    private void loadSavedAlerts() {
        try {
            List<Alert> alerts = db.loadAlerts();
            for (Alert alert : alerts) {
                addAlertToTable(alert);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,
                "Error loading alerts: " + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addAlertToTable(Alert alert) {
        tableModel.insertRow(0, new Object[]{
            alert.getTimestamp().format(DATE_FORMAT),
            alert.getBuilding().getName(),
            alert.getSeverity(),
            alert.getMessage()
        });
    }

    @Override
    public void onAlert(Alert alert) {
        SwingUtilities.invokeLater(() -> {
            try {
                db.saveAlert(alert);
                addAlertToTable(alert);
                
                if (!isVisible()) {
                    setVisible(true);
                }
                toFront();
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this,
                    "Error saving alert: " + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
    }
} 