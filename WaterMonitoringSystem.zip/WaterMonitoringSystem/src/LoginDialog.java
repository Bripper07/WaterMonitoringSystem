import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LoginDialog extends JDialog {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private boolean succeeded;
    private UserAuth userAuth;
    private JButton btnSignup;

    public LoginDialog(Frame parent, UserAuth userAuth) {
        super(parent, "Login", true);
        this.userAuth = userAuth;
        
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints cs = new GridBagConstraints();
        cs.fill = GridBagConstraints.HORIZONTAL;

        JLabel lbUsername = new JLabel("Username: ");
        cs.gridx = 0;
        cs.gridy = 0;
        cs.gridwidth = 1;
        panel.add(lbUsername, cs);

        usernameField = new JTextField(20);
        cs.gridx = 1;
        cs.gridy = 0;
        cs.gridwidth = 2;
        panel.add(usernameField, cs);

        JLabel lbPassword = new JLabel("Password: ");
        cs.gridx = 0;
        cs.gridy = 1;
        cs.gridwidth = 1;
        panel.add(lbPassword, cs);

        passwordField = new JPasswordField(20);
        cs.gridx = 1;
        cs.gridy = 1;
        cs.gridwidth = 2;
        panel.add(passwordField, cs);

        JButton btnLogin = new JButton("Login");
        btnSignup = new JButton("Sign Up");
        JButton btnCancel = new JButton("Cancel");

        JPanel bp = new JPanel();
        bp.add(btnLogin);
        bp.add(btnSignup);
        bp.add(btnCancel);

        btnLogin.addActionListener(e -> login());
        btnSignup.addActionListener(e -> showSignupDialog());
        btnCancel.addActionListener(e -> {
            succeeded = false;
            dispose();
        });

        getContentPane().add(panel, BorderLayout.CENTER);
        getContentPane().add(bp, BorderLayout.PAGE_END);

        pack();
        setResizable(false);
        setLocationRelativeTo(parent);
    }

    private void login() {
        if (userAuth.login(usernameField.getText(), new String(passwordField.getPassword()))) {
            succeeded = true;
            dispose();
        } else {
            JOptionPane.showMessageDialog(this,
                "Invalid username or password",
                "Login Failed",
                JOptionPane.ERROR_MESSAGE);
            usernameField.setText("");
            passwordField.setText("");
            succeeded = false;
        }
    }

    private void showSignupDialog() {
        SignupDialog signupDialog = new SignupDialog(null, userAuth);
        signupDialog.setVisible(true);
        if (signupDialog.isSucceeded()) {
            usernameField.setText("");
            passwordField.setText("");
        }
    }

    public boolean isSucceeded() {
        return succeeded;
    }
} 