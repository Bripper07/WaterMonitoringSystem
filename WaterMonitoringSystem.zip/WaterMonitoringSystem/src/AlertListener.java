public interface AlertListener {
    void onAlert(Alert alert);
} 