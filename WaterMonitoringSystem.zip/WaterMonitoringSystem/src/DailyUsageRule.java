import java.util.List;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

public class DailyUsageRule implements AlertRule {
    private double dailyThreshold;

    public DailyUsageRule(double dailyThreshold) {
        this.dailyThreshold = dailyThreshold;
    }

    @Override
    public boolean evaluate(List<WaterReading> readings) {
        if (readings.size() < 2) return false;

        // Get readings from the last 24 hours
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime dayAgo = now.minus(24, ChronoUnit.HOURS);

        double dailyUsage = readings.stream()
            .filter(r -> r.getTimestamp().isAfter(dayAgo))
            .mapToDouble(WaterReading::getValue)
            .sum();

        return dailyUsage > dailyThreshold;
    }

    @Override
    public String getDescription() {
        return String.format("Daily usage exceeded %.2f m³", dailyThreshold);
    }
} 