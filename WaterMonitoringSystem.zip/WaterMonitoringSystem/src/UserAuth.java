import java.sql.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class UserAuth {
    private DatabaseConnection db;
    private User currentUser;

    public UserAuth(DatabaseConnection db) {
        this.db = db;
        setupUserTable();
    }

    private void setupUserTable() {
        try {
            String createUsersTable = 
                "CREATE TABLE IF NOT EXISTS users (" +
                "    id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "    username TEXT UNIQUE," +
                "    password_hash TEXT," +
                "    role TEXT" +
                ")";

            String createUserBuildingsTable = 
                "CREATE TABLE IF NOT EXISTS user_buildings (" +
                "    user_id INTEGER," +
                "    building_id INTEGER," +
                "    FOREIGN KEY (user_id) REFERENCES users(id)," +
                "    FOREIGN KEY (building_id) REFERENCES buildings(id)" +
                ")";

            try (Statement stmt = db.getConnection().createStatement()) {
                stmt.execute(createUsersTable);
                stmt.execute(createUserBuildingsTable);
                
                // Create default admin user if none exists
                ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM users");
                if (rs.next() && rs.getInt(1) == 0) {
                    createUser("admin", "admin123", UserRole.ADMIN, new int[0]);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, 
                "Failed to setup user authentication: " + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean login(String username, String password) {
        try {
            String sql = "SELECT * FROM users WHERE username = ?";
            try (PreparedStatement pstmt = db.getConnection().prepareStatement(sql)) {
                pstmt.setString(1, username);
                ResultSet rs = pstmt.executeQuery();
                
                if (rs.next()) {
                    String storedHash = rs.getString("password_hash");
                    if (hashPassword(password).equals(storedHash)) {
                        // Load user's assigned buildings
                        int[] buildings = getUserBuildings(rs.getInt("id"));
                        currentUser = new User(
                            rs.getInt("id"),
                            username,
                            storedHash,
                            UserRole.valueOf(rs.getString("role")),
                            buildings
                        );
                        return true;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public void createUser(String username, String password, UserRole role, int[] buildings) throws SQLException {
        if (isUsernameTaken(username)) {
            throw new IllegalArgumentException("Username is already taken");
        }
        
        if (!PasswordValidator.isStrong(password)) {
            throw new IllegalArgumentException("Password does not meet requirements:\n" + 
                PasswordValidator.getRequirements());
        }

        String sql = "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = db.getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, username);
            pstmt.setString(2, hashPassword(password));
            pstmt.setString(3, role.name());
            pstmt.executeUpdate();
            
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                int userId = rs.getInt(1);
                assignBuildingsToUser(userId, buildings);
            }
        }
    }

    private void assignBuildingsToUser(int userId, int[] buildings) throws SQLException {
        String sql = "INSERT INTO user_buildings (user_id, building_id) VALUES (?, ?)";
        try (PreparedStatement pstmt = db.getConnection().prepareStatement(sql)) {
            for (int buildingId : buildings) {
                pstmt.setInt(1, userId);
                pstmt.setInt(2, buildingId);
                pstmt.executeUpdate();
            }
        }
    }

    private int[] getUserBuildings(int userId) throws SQLException {
        List<Integer> buildings = new ArrayList<>();
        String sql = "SELECT building_id FROM user_buildings WHERE user_id = ?";
        try (PreparedStatement pstmt = db.getConnection().prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                buildings.add(rs.getInt("building_id"));
            }
        }
        return buildings.stream().mapToInt(Integer::intValue).toArray();
    }

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                hexString.append(String.format("%02x", b));
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Failed to hash password", e);
        }
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public void logout() {
        currentUser = null;
    }

    public boolean isLoggedIn() {
        return currentUser != null;
    }

    public boolean canAccessBuilding(int buildingId) {
        return currentUser != null && currentUser.canAccessBuilding(buildingId);
    }

    public boolean isUsernameTaken(String username) {
        try {
            String sql = "SELECT COUNT(*) FROM users WHERE username = ?";
            try (PreparedStatement pstmt = db.getConnection().prepareStatement(sql)) {
                pstmt.setString(1, username);
                ResultSet rs = pstmt.executeQuery();
                return rs.next() && rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return true; // Assume taken in case of error
        }
    }

    public DatabaseConnection getDatabase() {
        return db;
    }
} 