public enum UserRole {
    ADMIN,
    MANAGER,
    VIEWER
} 