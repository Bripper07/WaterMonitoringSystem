import java.time.LocalDateTime;
import java.util.List;

public class WaterMeter {
    private DatabaseConnection db;

    public WaterMeter() {
        db = new DatabaseConnection();
    }

    /**
     * Records a water meter reading for a specific building
     * @param buildingId The ID of the building
     * @param reading The water meter reading in cubic meters
     * @throws IllegalArgumentException if reading is negative or buildingId is invalid
     */
    public void recordReading(int buildingId, double reading) {
        // Validate inputs
        if (buildingId <= 0) {
            throw new IllegalArgumentException("Building ID must be positive");
        }
        if (reading < 0) {
            throw new IllegalArgumentException("Water reading cannot be negative");
        }

        try {
            db.addReading(buildingId, reading, LocalDateTime.now());
        } catch (Exception e) {
            throw new RuntimeException("Failed to record reading: " + e.getMessage());
        }
    }

    /**
     * Retrieves the latest reading for a building
     * @param buildingId The ID of the building
     * @return The latest water meter reading
     * @throws IllegalArgumentException if buildingId is invalid
     */
    public double getLatestReading(int buildingId) {
        // Implementation needed
        throw new UnsupportedOperationException("Method not implemented");
    }

    /**
     * Gets the database connection
     * @return The DatabaseConnection instance
     */
    public DatabaseConnection getDatabase() {
        return db;
    }

    public List<WaterReading> getReadings(int buildingId) {
        try {
            return db.getReadings(buildingId);
        } catch (Exception e) {
            throw new RuntimeException("Failed to retrieve readings: " + e.getMessage());
        }
    }

    public void close() {
        db.close();
    }
} 