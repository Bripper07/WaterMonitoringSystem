import java.time.LocalDateTime;

public class WaterReading {
    private int buildingId;
    private double value;
    private LocalDateTime timestamp;

    public WaterReading(int buildingId, double value, LocalDateTime timestamp) {
        this.buildingId = buildingId;
        this.value = value;
        this.timestamp = timestamp;
    }

    public int getBuildingId() {
        return buildingId;
    }

    public double getValue() {
        return value;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    @Override
    public String toString() {
        return String.format("Building %d: %.2f m³ at %s", 
            buildingId, value, timestamp.toString());
    }
} 