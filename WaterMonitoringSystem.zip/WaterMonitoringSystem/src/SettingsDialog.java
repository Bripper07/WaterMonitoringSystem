import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class SettingsDialog extends JDialog {
    private UserAuth userAuth;
    private JTabbedPane tabbedPane;
    private DefaultListModel<Building> buildingListModel;
    private JList<Building> buildingList;
    private JTextField buildingNameField;
    private JTextField buildingAddressField;

    public SettingsDialog(Frame parent, UserAuth userAuth) {
        super(parent, "Settings", true);
        this.userAuth = userAuth;

        // Only allow admin to access settings
        if (userAuth.getCurrentUser().getRole() != UserRole.ADMIN) {
            JOptionPane.showMessageDialog(this,
                "Only administrators can access settings",
                "Access Denied",
                JOptionPane.ERROR_MESSAGE);
            dispose();
            return;
        }

        setupUI();
    }

    private void setupUI() {
        setLayout(new BorderLayout());
        tabbedPane = new JTabbedPane();

        // Buildings Panel
        tabbedPane.addTab("Buildings", createBuildingsPanel());

        // Add more tabs here as needed
        // tabbedPane.addTab("Users", createUsersPanel());
        // tabbedPane.addTab("System", createSystemPanel());

        add(tabbedPane, BorderLayout.CENTER);

        // Close button at bottom
        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> dispose());
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(closeButton);
        add(buttonPanel, BorderLayout.SOUTH);

        setSize(600, 400);
        setLocationRelativeTo(getParent());
    }

    private JPanel createBuildingsPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Building List
        buildingListModel = new DefaultListModel<>();
        buildingList = new JList<>(buildingListModel);
        refreshBuildingList();

        JScrollPane scrollPane = new JScrollPane(buildingList);
        scrollPane.setPreferredSize(new Dimension(200, 300));
        panel.add(scrollPane, BorderLayout.WEST);

        // Building Details
        JPanel detailsPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        gbc.gridx = 0; gbc.gridy = 0;
        detailsPanel.add(new JLabel("Building Name:"), gbc);

        gbc.gridx = 1;
        buildingNameField = new JTextField(20);
        detailsPanel.add(buildingNameField, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        detailsPanel.add(new JLabel("Address:"), gbc);

        gbc.gridx = 1;
        buildingAddressField = new JTextField(20);
        detailsPanel.add(buildingAddressField, gbc);

        // Buttons
        JPanel buttonPanel = new JPanel();
        JButton addButton = new JButton("Add Building");
        JButton deleteButton = new JButton("Delete Building");

        addButton.addActionListener(e -> addBuilding());
        deleteButton.addActionListener(e -> deleteBuilding());

        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);

        gbc.gridx = 0; gbc.gridy = 2;
        gbc.gridwidth = 2;
        detailsPanel.add(buttonPanel, gbc);

        panel.add(detailsPanel, BorderLayout.CENTER);

        return panel;
    }

    private void refreshBuildingList() {
        buildingListModel.clear();
        try {
            List<Building> buildings = userAuth.getDatabase().getAllBuildings();
            for (Building building : buildings) {
                buildingListModel.addElement(building);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,
                "Error loading buildings: " + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addBuilding() {
        String name = buildingNameField.getText().trim();
        String address = buildingAddressField.getText().trim();

        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Building name is required",
                "Validation Error",
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            userAuth.getDatabase().addBuilding(name, address);
            refreshBuildingList();
            buildingNameField.setText("");
            buildingAddressField.setText("");
            JOptionPane.showMessageDialog(this,
                "Building added successfully",
                "Success",
                JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,
                "Error adding building: " + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteBuilding() {
        Building selected = buildingList.getSelectedValue();
        if (selected == null) {
            JOptionPane.showMessageDialog(this,
                "Please select a building to delete",
                "Selection Required",
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to delete " + selected.getName() + "?\n" +
            "This will also delete all associated water readings.",
            "Confirm Delete",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                // Add method to delete building
                // userAuth.getDatabase().deleteBuilding(selected.getId());
                refreshBuildingList();
                JOptionPane.showMessageDialog(this,
                    "Building deleted successfully",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this,
                    "Error deleting building: " + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }
} 