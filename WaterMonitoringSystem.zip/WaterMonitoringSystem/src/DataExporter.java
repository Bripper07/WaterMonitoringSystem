import java.io.*;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

public class DataExporter {
    private DatabaseConnection db;
    private static final DateTimeFormatter DATE_FORMAT = 
        DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public DataExporter(DatabaseConnection db) {
        this.db = db;
    }

    public void exportToCSV(int buildingId) {
        try {
            List<WaterReading> readings = db.getReadings(buildingId);
            if (readings.isEmpty()) {
                throw new IllegalStateException("No data available to export");
            }

            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Save Water Consumption Data");
            fileChooser.setFileFilter(new FileNameExtensionFilter("CSV files (*.csv)", "csv"));
            fileChooser.setSelectedFile(new File("water_consumption_building_" + buildingId + ".csv"));

            if (fileChooser.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {
                File file = fileChooser.getSelectedFile();
                if (!file.getName().toLowerCase().endsWith(".csv")) {
                    file = new File(file.getParentFile(), file.getName() + ".csv");
                }

                try (PrintWriter writer = new PrintWriter(new FileWriter(file))) {
                    // Write CSV header
                    writer.println("Timestamp,Building ID,Reading (m³)");

                    // Write data rows
                    for (WaterReading reading : readings) {
                        writer.printf("%s,%d,%.2f%n",
                            reading.getTimestamp().format(DATE_FORMAT),
                            reading.getBuildingId(),
                            reading.getValue()
                        );
                    }
                }
                return;
            }
        } catch (Exception e) {
            throw new RuntimeException("Failed to export data: " + e.getMessage(), e);
        }
    }
} 