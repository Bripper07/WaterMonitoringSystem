import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.DecimalFormat;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;
import javax.swing.table.DefaultTableModel;
import java.sql.SQLException;
import java.util.List;

public class WaterMonitoringGUI extends JFrame {
    private WaterMeter waterMeter;
    private JTextField buildingIdField;
    private JTextField readingField;
    private JTextArea displayArea;
    private JLabel statusLabel;
    private WaterConsumptionChart chart;
    private JTable readingsTable;
    private DefaultTableModel tableModel;
    private ConsumptionAnalyzer analyzer;
    private JTextArea analysisArea;
    private UserAuth userAuth;
    private DataExporter dataExporter;
    private JComboBox<Building> buildingSelector;
    private AlertSystem alertSystem;
    private AlertDialog alertDialog;

    public WaterMonitoringGUI(WaterMeter waterMeter) {
        this.waterMeter = waterMeter;
        this.analyzer = new ConsumptionAnalyzer(waterMeter.getDatabase());
        this.userAuth = new UserAuth(waterMeter.getDatabase());
        this.dataExporter = new DataExporter(waterMeter.getDatabase());
        
        this.alertSystem = new AlertSystem(waterMeter.getDatabase());
        this.alertDialog = new AlertDialog(this, waterMeter.getDatabase());
        this.alertSystem.addListener(alertDialog);
        
        // Add shutdown hook for alert system
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            alertSystem.shutdown();
        }));
        
        // Show login dialog before setting up GUI
        while (true) {
            LoginDialog loginDialog = new LoginDialog(this, userAuth);
            loginDialog.setVisible(true);
            
            if (loginDialog.isSucceeded()) {
                break;
            } else {
                int option = JOptionPane.showConfirmDialog(this,
                    "Would you like to try logging in again?",
                    "Login Failed",
                    JOptionPane.YES_NO_OPTION);
                if (option != JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        }
        
        setupGUI();
    }

    private void setupGUI() {
        setTitle("Water Monitoring System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));
        
        // Create main split pane
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        
        // Top panel with input and buttons
        JPanel topPanel = new JPanel(new BorderLayout(5, 5));
        
        // Input Panel
        JPanel inputPanel = createInputPanel();
        
        // Button Panel
        JPanel buttonPanel = createButtonPanel();
        
        topPanel.add(inputPanel, BorderLayout.CENTER);
        topPanel.add(buttonPanel, BorderLayout.EAST);
        
        // Create tabbed pane for different views
        JTabbedPane tabbedPane = new JTabbedPane();
        
        // Chart Panel
        chart = new WaterConsumptionChart();
        tabbedPane.addTab("Chart", chart);
        
        // Table Panel
        JPanel tablePanel = createTablePanel();
        tabbedPane.addTab("Data Table", tablePanel);
        
        // Reading History Panel
        displayArea = new JTextArea(10, 40);
        displayArea.setEditable(false);
        JScrollPane historyScrollPane = new JScrollPane(displayArea);
        historyScrollPane.setBorder(BorderFactory.createTitledBorder("Reading History"));
        tabbedPane.addTab("History", historyScrollPane);
        
        // Analysis Panel
        JPanel analysisPanel = createAnalysisPanel();
        tabbedPane.addTab("Analysis", analysisPanel);

        // Add components to split pane
        splitPane.setTopComponent(topPanel);
        splitPane.setBottomComponent(tabbedPane);
        splitPane.setDividerLocation(150);

        // Status Label
        statusLabel = new JLabel("Ready");
        statusLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        // Add components to frame
        add(splitPane, BorderLayout.CENTER);
        add(statusLabel, BorderLayout.SOUTH);

        // Window settings
        setSize(800, 600);
        setLocationRelativeTo(null);
    }

    private JPanel createInputPanel() {
        JPanel inputPanel = new JPanel(new GridLayout(3, 2, 5, 5));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Input Reading"));
        
        buildingSelector = new JComboBox<>();
        updateBuildingSelector();
        
        inputPanel.add(new JLabel("Building:"));
        inputPanel.add(buildingSelector);
        
        readingField = new JTextField(10);
        JButton submitButton = new JButton("Submit Reading");
        
        inputPanel.add(new JLabel("Reading (m³):"));
        inputPanel.add(readingField);
        inputPanel.add(new JLabel(""));
        inputPanel.add(submitButton);
        
        submitButton.addActionListener(e -> submitReading());
        
        return inputPanel;
    }

    private JPanel createButtonPanel() {
        JPanel buttonPanel = new JPanel(new GridLayout(4, 1, 5, 5));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        
        JButton exportButton = new JButton("Export Data");
        JButton settingsButton = new JButton("Settings");
        JButton helpButton = new JButton("Help");
        JButton alertsButton = new JButton("Alerts");
        
        exportButton.addActionListener(this::exportData);
        settingsButton.addActionListener(this::showSettings);
        helpButton.addActionListener(this::showHelp);
        alertsButton.addActionListener(e -> alertDialog.setVisible(true));
        
        buttonPanel.add(exportButton);
        buttonPanel.add(settingsButton);
        buttonPanel.add(helpButton);
        buttonPanel.add(alertsButton);
        
        return buttonPanel;
    }

    private JPanel createTablePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        
        String[] columns = {"Date/Time", "Building ID", "Reading (m³)"};
        tableModel = new DefaultTableModel(columns, 0);
        readingsTable = new JTable(tableModel);
        
        JScrollPane scrollPane = new JScrollPane(readingsTable);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        return panel;
    }

    private JPanel createAnalysisPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Consumption Analysis"));
        
        analysisArea = new JTextArea(8, 40);
        analysisArea.setEditable(false);
        analysisArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        
        JScrollPane scrollPane = new JScrollPane(analysisArea);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        return panel;
    }

    private void updateBuildingSelector() {
        buildingSelector.removeAllItems();
        try {
            List<Building> buildings = waterMeter.getDatabase().getAllBuildings();
            for (Building building : buildings) {
                if (userAuth.canAccessBuilding(building.getId())) {
                    buildingSelector.addItem(building);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void submitReading() {
        try {
            Building selectedBuilding = (Building) buildingSelector.getSelectedItem();
            if (selectedBuilding == null) {
                statusLabel.setText("Error: Please select a building");
                statusLabel.setForeground(Color.RED);
                return;
            }
            
            if (!userAuth.canAccessBuilding(selectedBuilding.getId())) {
                statusLabel.setText("Error: You don't have permission to access this building");
                statusLabel.setForeground(Color.RED);
                return;
            }
            
            double reading = Double.parseDouble(readingField.getText());
            
            waterMeter.recordReading(selectedBuilding.getId(), reading);
            LocalDateTime now = LocalDateTime.now();
            
            // Update chart
            chart.addReading(now, reading);
            
            // Update table
            tableModel.addRow(new Object[]{
                now.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")),
                selectedBuilding.getName(),
                new DecimalFormat("#.##").format(reading)
            });
            
            // Clear input fields
            readingField.setText("");
            
            // Perform analysis
            AnalysisResult analysis = analyzer.analyzeConsumption(selectedBuilding.getId());
            analysisArea.setText(analysis.getMessage());
            
            if (analysis.isAnomalyDetected()) {
                statusLabel.setText("Warning: Anomaly detected!");
                statusLabel.setForeground(Color.RED);
            } else {
                statusLabel.setText("Reading recorded successfully!");
                statusLabel.setForeground(new Color(0, 150, 0));
            }

        } catch (NumberFormatException ex) {
            statusLabel.setText("Error: Please enter valid numbers");
            statusLabel.setForeground(Color.RED);
        } catch (IllegalArgumentException ex) {
            statusLabel.setText("Error: " + ex.getMessage());
            statusLabel.setForeground(Color.RED);
        }
    }

    private void exportData(ActionEvent e) {
        try {
            String input = JOptionPane.showInputDialog(this, 
                "Enter Building ID to export:", 
                "Export Data", 
                JOptionPane.QUESTION_MESSAGE);
            
            if (input != null && !input.trim().isEmpty()) {
                int buildingId = Integer.parseInt(input);
                
                if (!userAuth.canAccessBuilding(buildingId)) {
                    JOptionPane.showMessageDialog(this,
                        "You don't have permission to access this building's data",
                        "Access Denied",
                        JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                dataExporter.exportToCSV(buildingId);
                JOptionPane.showMessageDialog(this,
                    "Data exported successfully!",
                    "Export Complete",
                    JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                "Please enter a valid building ID",
                "Invalid Input",
                JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                "Error exporting data: " + ex.getMessage(),
                "Export Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void showSettings(ActionEvent e) {
        SettingsDialog settingsDialog = new SettingsDialog(this, userAuth);
        settingsDialog.setVisible(true);
        // Refresh building selector after settings dialog closes
        updateBuildingSelector();
    }

    private void showHelp(ActionEvent e) {
        JOptionPane.showMessageDialog(this,
            "Water Monitoring System Help\n\n" +
            "1. Enter Building ID (positive number)\n" +
            "2. Enter Water Reading in cubic meters\n" +
            "3. Click Submit to record the reading\n\n" +
            "Use the tabs below to view data in different formats.\n" +
            "Export button allows you to save data to a file.",
            "Help",
            JOptionPane.INFORMATION_MESSAGE);
    }

    public void display() {
        setVisible(true);
    }
} 