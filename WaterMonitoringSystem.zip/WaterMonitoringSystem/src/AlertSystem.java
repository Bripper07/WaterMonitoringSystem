import java.util.*;
import java.time.LocalDateTime;
import javax.swing.Timer;
import java.sql.SQLException;

public class AlertSystem {
    private List<AlertRule> rules;
    private List<AlertListener> listeners;
    private DatabaseConnection db;
    private Timer checkTimer;
    private static final int CHECK_INTERVAL = 60000; // Check every minute

    public AlertSystem(DatabaseConnection db) {
        this.db = db;
        this.rules = new ArrayList<>();
        this.listeners = new ArrayList<>();
        
        try {
            db.createAlertTable();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        // Add default rules
        rules.add(new ConsumptionSpikeRule(30.0)); // 30% above average
        rules.add(new DailyUsageRule(1000.0));
        
        // Start periodic checking
        checkTimer = new Timer(CHECK_INTERVAL, e -> checkAlerts());
        checkTimer.start();
    }

    public void addListener(AlertListener listener) {
        listeners.add(listener);
    }

    public void removeListener(AlertListener listener) {
        listeners.remove(listener);
    }

    private void checkAlerts() {
        try {
            List<Building> buildings = db.getAllBuildings();
            for (Building building : buildings) {
                List<WaterReading> readings = db.getReadings(building.getId());
                if (!readings.isEmpty()) {
                    for (AlertRule rule : rules) {
                        if (rule.evaluate(readings)) {
                            Alert alert = new Alert(
                                building,
                                rule.getDescription(),
                                LocalDateTime.now(),
                                AlertSeverity.HIGH
                            );
                            notifyListeners(alert);
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void notifyListeners(Alert alert) {
        for (AlertListener listener : listeners) {
            listener.onAlert(alert);
        }
    }

    public void shutdown() {
        if (checkTimer != null) {
            checkTimer.stop();
        }
    }
} 