public class AnalysisResult {
    private double dailyConsumption;
    private double averageConsumption;
    private double weeklyAverage;
    private boolean anomalyDetected;
    private String message;

    public AnalysisResult(double dailyConsumption, double averageConsumption, 
                         double weeklyAverage, boolean anomalyDetected, String message) {
        this.dailyConsumption = dailyConsumption;
        this.averageConsumption = averageConsumption;
        this.weeklyAverage = weeklyAverage;
        this.anomalyDetected = anomalyDetected;
        this.message = message;
    }

    public double getDailyConsumption() {
        return dailyConsumption;
    }

    public double getAverageConsumption() {
        return averageConsumption;
    }

    public double getWeeklyAverage() {
        return weeklyAverage;
    }

    public boolean isAnomalyDetected() {
        return anomalyDetected;
    }

    public String getMessage() {
        return message;
    }
} 