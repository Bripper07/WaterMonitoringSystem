# Water Monitoring System

## Setup Instructions
1. Extract the zip file
2. Open the project in your Java IDE:
   - For VS Code: Open the folder and install "Extension Pack for Java"
   - For Eclipse: Import as "Existing Java Project"
   - For IntelliJ: Open as project

3. Make sure the SQLite JDBC driver (in lib folder) is in your project's classpath

4. Run App.java to start the application

## Default Login
Username: admin
Password: admin123!

## Project Files
- src/ - Contains all the Java source code
- lib/ - Contains the SQLite database driver

## Features
- Real-time water consumption monitoring
- Multi-building support
- User authentication and authorization
- Data analysis and visualization
- Alert system for anomalies
- Data export functionality
